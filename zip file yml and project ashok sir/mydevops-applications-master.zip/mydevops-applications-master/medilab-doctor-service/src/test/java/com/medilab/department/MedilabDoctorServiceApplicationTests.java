package com.medilab.department;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedilabDoctorServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
