package com.medilab.doctor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedilabDoctorServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedilabDoctorServiceApplication.class, args);
	}

}
