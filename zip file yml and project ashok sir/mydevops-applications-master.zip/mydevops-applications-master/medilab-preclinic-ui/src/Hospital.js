import React, { Component } from 'react'

export class Hospital extends Component {
    render() {
        return (
            <div>
                <h3>Welcoem to Evening Preclinic</h3>
            </div>
        )
    }
}

export default Hospital
