import React, { Component } from 'react'

import DashboardHeader from './DashboardHeader'
export class Dashboard extends Component {
    
    render() {
        return (
            <div>

                <DashboardHeader/>
                <h3>This is Medilab Dashbaord</h3>
            </div>
        )
    }
}

export default Dashboard
