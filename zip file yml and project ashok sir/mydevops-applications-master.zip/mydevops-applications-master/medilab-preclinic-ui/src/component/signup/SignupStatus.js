import React, { Component } from 'react'

export class SignupStatus extends Component {
    render() {
        return (
            <div>
                
            </div>
        )
    }
}

export default SignupStatus
