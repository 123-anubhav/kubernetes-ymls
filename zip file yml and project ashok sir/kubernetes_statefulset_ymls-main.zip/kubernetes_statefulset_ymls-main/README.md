# Kubernetes StatefulSet Configuration

# Step-1 : Execute Namespace manifest

   $ kubectl apply -f <filename>
 
# Step-2 : Execute PV manifest

   $ kubectl apply -f <filename>
   
# Step-3 : Execute PVC manifest

   $ kubectl apply -f <filename>
   
# Step-4 : Execute configMap manifest

   $ kubectl apply -f <filename>
     
# Step-5 : Execute StatefulSet manifest

    $ kubectl apply -f <filename>

# Step-6 : Execute Service Manifest (Headless Service)

    $ kubectl apply -f <filename>
